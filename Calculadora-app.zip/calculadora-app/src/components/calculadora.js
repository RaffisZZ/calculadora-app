export default {
    data() {
      return {
        valorCorrente: '',
        numeroAnterior: null,
        operador: null,
        operadorClicado: false,
      };
    },
    methods: {
      
      limpar() {
        this.valorCorrente = '';
      },

      sinal() {
        this.valorCorrente = this.valorCorrente.charAt(0) === '-'
          ? this.valorCorrente.slice(1)
          : `-${this.valorCorrente}`;
      },
  
     
      porcentagem() {
        this.valorCorrente = `${parseFloat(this.valorCorrente) / 100}`;
      },
  
      
      juntarNumeros(numero) {
        if (this.operadorClicado) {
          this.valorCorrente = '';
          this.operadorClicado = false;
        }
  
        this.valorCorrente = `${this.valorCorrente}${numero}`;
      },
  
      
      ponto() {
        if (this.valorCorrente.indexOf('.') === -1) {
          this.juntarNumeros('.');
        }
      },
  
      setarValor() {
        this.numeroAnterior = this.valorCorrente;
        this.operadorClicado = true;
      },
  
      
      dividir() {
        this.operador = (num1, num2) => num1 / num2;
        this.setarValor();
      },
  
    
      multiplicar() {
        this.operador = (num1, num2) => num1 * num2;
        this.setarValor();
      },
  
      
      diminuir() {
        this.operador = (num1, num2) => num1 - num2;
        this.setarValor();
      },
  
      
      somar() {
        this.operador = (num1, num2) => num1 + num2;
        this.setarValor();
      },

 
        log10() {
          this.operador = (num) => Math.log10(num);
          this.setarValor();
        },

      
      logBase() {
        this.operador = (num1, num2) => Math.log(num1) / Math.log(num2);
        this.setarValor();
      },

      
      raizQuadrada() {
        this.operador = (num) => Math.sqrt(num);
        this.setarValor();
      },

     
      raiz() {
        this.operador = (num1, num2) => Math.pow(num1, 1 / num2);
        this.setarValor();
      },

      
      aoQuadrado() {
        this.operador = (num) => Math.pow(num, 2);
        this.setarValor();
      },

     
      potencia() {
        this.operador = (num1, num2) => Math.pow(num1, num2);
        this.setarValor();
      },
    
    
      resultado() {
        this.valorCorrente = `${this.operador(
          parseFloat(this.numeroAnterior),
          parseFloat(this.valorCorrente),
        )}`;
        this.numeroAnterior = null;
      },
    },
  };